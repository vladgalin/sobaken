#!/bin/bash

echo "Привет, $USER!"
echo "Сегодня $(date)"
